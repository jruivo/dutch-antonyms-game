/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.chrisley;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.Toolkit;
import java.net.URL;
import javax.swing.JOptionPane;

/**
 *
 * @author chrysthian.chrisley
 */
public class Antoniemen extends javax.swing.JFrame {

    public Antoniemen() {
        initComponents();
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/images/netherlands.png")));

    }

    public int acertos;
    public int erros;
    public int clicks;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        slecht = new javax.swing.JButton();
        laat = new javax.swing.JButton();
        volwassene = new javax.swing.JButton();
        geslaagd = new javax.swing.JButton();
        kind = new javax.swing.JButton();
        dag = new javax.swing.JButton();
        mogelijk = new javax.swing.JButton();
        slim = new javax.swing.JButton();
        niemand = new javax.swing.JButton();
        zwaar = new javax.swing.JButton();
        uitgang = new javax.swing.JButton();
        goed = new javax.swing.JButton();
        kort = new javax.swing.JButton();
        gezakt = new javax.swing.JButton();
        vroeg = new javax.swing.JButton();
        meisje = new javax.swing.JButton();
        moeder = new javax.swing.JButton();
        jongen = new javax.swing.JButton();
        dom = new javax.swing.JButton();
        glanzend = new javax.swing.JButton();
        vader = new javax.swing.JButton();
        nacht = new javax.swing.JButton();
        niets = new javax.swing.JButton();
        vrij = new javax.swing.JButton();
        onmogelijk = new javax.swing.JButton();
        bezet = new javax.swing.JButton();
        lang = new javax.swing.JButton();
        dof = new javax.swing.JButton();
        iets = new javax.swing.JButton();
        licht = new javax.swing.JButton();
        ingang = new javax.swing.JButton();
        iemand = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem5 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Antoniemen");
        setAutoRequestFocus(false);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 0, 0), new java.awt.Color(204, 204, 204)));

        slecht.setText("Slecht");
        slecht.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                slechtMouseClicked(evt);
            }
        });
        slecht.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                slechtActionPerformed(evt);
            }
        });

        laat.setText("Laat");
        laat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                laatActionPerformed(evt);
            }
        });

        volwassene.setText("Volwassene");
        volwassene.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                volwasseneActionPerformed(evt);
            }
        });

        geslaagd.setText("Geslaagd");
        geslaagd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                geslaagdActionPerformed(evt);
            }
        });

        kind.setText("Kind");
        kind.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kindActionPerformed(evt);
            }
        });

        dag.setText("Dag");
        dag.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dagActionPerformed(evt);
            }
        });

        mogelijk.setText("Mogelijk");
        mogelijk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mogelijkActionPerformed(evt);
            }
        });

        slim.setText("Slim");
        slim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                slimActionPerformed(evt);
            }
        });

        niemand.setText("Niemand");
        niemand.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                niemandMouseClicked(evt);
            }
        });
        niemand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                niemandActionPerformed(evt);
            }
        });

        zwaar.setText("Zwaar");
        zwaar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                zwaarActionPerformed(evt);
            }
        });

        uitgang.setText("Uitgang");
        uitgang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uitgangActionPerformed(evt);
            }
        });

        goed.setText("Goed");
        goed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                goedActionPerformed(evt);
            }
        });

        kort.setText("Kort");
        kort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kortActionPerformed(evt);
            }
        });

        gezakt.setText("Gezakt");
        gezakt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gezaktActionPerformed(evt);
            }
        });

        vroeg.setText("Vroeg");
        vroeg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vroegActionPerformed(evt);
            }
        });

        meisje.setText("Meisje");
        meisje.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                meisjeMouseClicked(evt);
            }
        });
        meisje.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                meisjeActionPerformed(evt);
            }
        });

        moeder.setText("Moeder");
        moeder.setToolTipText("Testando");
        moeder.setName(""); // NOI18N
        moeder.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                moederMouseClicked(evt);
            }
        });
        moeder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                moederActionPerformed(evt);
            }
        });

        jongen.setText("Jongen");
        jongen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jongenMouseClicked(evt);
            }
        });
        jongen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jongenActionPerformed(evt);
            }
        });

        dom.setText("Dom");
        dom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                domActionPerformed(evt);
            }
        });

        glanzend.setText("Glanzend");
        glanzend.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                glanzendActionPerformed(evt);
            }
        });

        vader.setText("Vader");
        vader.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vaderActionPerformed(evt);
            }
        });

        nacht.setText("Nacht");
        nacht.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nachtActionPerformed(evt);
            }
        });

        niets.setText("Niets");
        niets.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nietsActionPerformed(evt);
            }
        });

        vrij.setText("Vrij");
        vrij.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vrijActionPerformed(evt);
            }
        });

        onmogelijk.setText("Onmogelijk");
        onmogelijk.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                onmogelijkMouseClicked(evt);
            }
        });
        onmogelijk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                onmogelijkActionPerformed(evt);
            }
        });

        bezet.setText("Bezet");
        bezet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bezetActionPerformed(evt);
            }
        });

        lang.setText("Lang");
        lang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                langActionPerformed(evt);
            }
        });

        dof.setText("Dof");
        dof.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dofActionPerformed(evt);
            }
        });

        iets.setText("Iets");
        iets.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ietsActionPerformed(evt);
            }
        });

        licht.setText("Licht");
        licht.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lichtActionPerformed(evt);
            }
        });

        ingang.setText("Ingang");
        ingang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ingangActionPerformed(evt);
            }
        });

        iemand.setText("Iemand");
        iemand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iemandActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(slecht)
                        .addGap(18, 18, 18)
                        .addComponent(niemand)
                        .addGap(18, 18, 18)
                        .addComponent(moeder)
                        .addGap(18, 18, 18)
                        .addComponent(onmogelijk))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(laat)
                        .addGap(18, 18, 18)
                        .addComponent(zwaar)
                        .addGap(18, 18, 18)
                        .addComponent(jongen)
                        .addGap(18, 18, 18)
                        .addComponent(bezet))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(volwassene)
                        .addGap(18, 18, 18)
                        .addComponent(uitgang)
                        .addGap(18, 18, 18)
                        .addComponent(dom)
                        .addGap(18, 18, 18)
                        .addComponent(lang))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(geslaagd)
                        .addGap(18, 18, 18)
                        .addComponent(goed)
                        .addGap(18, 18, 18)
                        .addComponent(glanzend)
                        .addGap(18, 18, 18)
                        .addComponent(dof))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(kind)
                        .addGap(18, 18, 18)
                        .addComponent(kort)
                        .addGap(18, 18, 18)
                        .addComponent(vader)
                        .addGap(18, 18, 18)
                        .addComponent(iets))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(dag)
                        .addGap(18, 18, 18)
                        .addComponent(gezakt)
                        .addGap(18, 18, 18)
                        .addComponent(nacht)
                        .addGap(18, 18, 18)
                        .addComponent(licht))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(mogelijk)
                        .addGap(18, 18, 18)
                        .addComponent(vroeg)
                        .addGap(18, 18, 18)
                        .addComponent(niets)
                        .addGap(18, 18, 18)
                        .addComponent(ingang))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(slim)
                        .addGap(18, 18, 18)
                        .addComponent(meisje)
                        .addGap(18, 18, 18)
                        .addComponent(vrij)
                        .addGap(18, 18, 18)
                        .addComponent(iemand)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {bezet, dag, dof, dom, geslaagd, gezakt, glanzend, goed, iemand, iets, ingang, jongen, kind, kort, laat, lang, licht, meisje, moeder, mogelijk, nacht, niemand, niets, onmogelijk, slecht, slim, uitgang, vader, volwassene, vrij, vroeg, zwaar});

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(slecht)
                    .addComponent(niemand)
                    .addComponent(moeder)
                    .addComponent(onmogelijk))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(laat)
                    .addComponent(zwaar)
                    .addComponent(jongen)
                    .addComponent(bezet))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(volwassene)
                    .addComponent(uitgang)
                    .addComponent(dom)
                    .addComponent(lang))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(geslaagd)
                    .addComponent(goed)
                    .addComponent(glanzend)
                    .addComponent(dof))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(kind)
                    .addComponent(kort)
                    .addComponent(vader)
                    .addComponent(iets))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dag)
                    .addComponent(gezakt)
                    .addComponent(nacht)
                    .addComponent(licht))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(mogelijk)
                    .addComponent(vroeg)
                    .addComponent(niets)
                    .addComponent(ingang))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(slim)
                    .addComponent(meisje)
                    .addComponent(vrij)
                    .addComponent(iemand))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        moeder.getAccessibleContext().setAccessibleDescription("");

        jMenu1.setText("File");

        jMenuItem4.setText("Novo");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem4);

        jMenuItem6.setText("Sair");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem6);

        jMenuBar1.add(jMenu1);

        jMenu3.setText("Help");

        jMenuItem5.setText("About");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem5);

        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void slechtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_slechtActionPerformed

        // Verificação de cartas abertas,  
        // MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || slim.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            slim.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            slecht.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (goed.isEnabled() == false) {

                slecht.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                goed.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_slechtActionPerformed

    private void niemandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_niemandActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            niemand.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (iemand.isEnabled() == false) {

                niemand.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                iemand.setEnabled(false);
            }
        }

    }//GEN-LAST:event_niemandActionPerformed

    private void moederActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_moederActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            moeder.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (vader.isEnabled() == false) {

                moeder.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                vader.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_moederActionPerformed

    private void onmogelijkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_onmogelijkActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            onmogelijk.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (mogelijk.isEnabled() == false) {

                onmogelijk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                mogelijk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_onmogelijkActionPerformed

    private void laatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_laatActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            laat.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (vroeg.isEnabled() == false) {

                laat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                vroeg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_laatActionPerformed

    private void zwaarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_zwaarActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            zwaar.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (licht.isEnabled() == false) {

                zwaar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                licht.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_zwaarActionPerformed

    private void jongenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jongenActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            jongen.setEnabled(false);

        }

        // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
        // CARTA EQUIVALENTE ABAIXO
        if (meisje.isEnabled() == false) {

            jongen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            meisje.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
             
            

        }


    }//GEN-LAST:event_jongenActionPerformed

    private void bezetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bezetActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            bezet.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (vrij.isEnabled() == false) {

                bezet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                vrij.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_bezetActionPerformed

    private void volwasseneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_volwasseneActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            volwassene.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (kind.isEnabled() == false) {

                kind.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                volwassene.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_volwasseneActionPerformed

    private void uitgangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uitgangActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            uitgang.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (ingang.isEnabled() == false) {

                uitgang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                ingang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_uitgangActionPerformed

    private void domActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_domActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            dom.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (slim.isEnabled() == false) {

                dom.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                slim.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_domActionPerformed

    private void langActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_langActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            lang.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (kort.isEnabled() == false) {

                lang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                kort.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_langActionPerformed

    private void geslaagdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_geslaagdActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            geslaagd.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (gezakt.isEnabled() == false) {

                geslaagd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                gezakt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_geslaagdActionPerformed

    private void goedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_goedActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            goed.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (slecht.isEnabled() == false) {

                goed.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                slecht.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_goedActionPerformed

    private void glanzendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_glanzendActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            glanzend.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (dof.isEnabled() == false) {

                glanzend.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                dof.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_glanzendActionPerformed

    private void dofActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dofActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            dof.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (glanzend.isEnabled() == false) {

                dof.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                glanzend.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_dofActionPerformed

    private void kindActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kindActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            kind.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (volwassene.isEnabled() == false) {

                kind.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                volwassene.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_kindActionPerformed

    private void kortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kortActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            kort.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (lang.isEnabled() == false) {

                kort.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                lang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_kortActionPerformed

    private void vaderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vaderActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            vader.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (moeder.isEnabled() == false) {

                vader.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                moeder.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_vaderActionPerformed

    private void ietsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ietsActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            iets.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (niets.isEnabled() == false) {

                iets.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                niets.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_ietsActionPerformed

    private void dagActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dagActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            dag.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (nacht.isEnabled() == false) {

                dag.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                nacht.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_dagActionPerformed

    private void gezaktActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gezaktActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            gezakt.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (geslaagd.isEnabled() == false) {

                gezakt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                geslaagd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_gezaktActionPerformed

    private void nachtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nachtActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            nacht.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (dag.isEnabled() == false) {

                nacht.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                dag.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_nachtActionPerformed

    private void lichtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lichtActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            licht.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (zwaar.isEnabled() == false) {

                licht.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                zwaar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_lichtActionPerformed

    private void mogelijkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mogelijkActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            mogelijk.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (onmogelijk.isEnabled() == false) {

                mogelijk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                onmogelijk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_mogelijkActionPerformed

    private void vroegActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vroegActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            vroeg.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (laat.isEnabled() == false) {

                vroeg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                laat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_vroegActionPerformed

    private void nietsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nietsActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            niets.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (iets.isEnabled() == false) {

                niets.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                iets.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_nietsActionPerformed

    private void ingangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ingangActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            ingang.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (uitgang.isEnabled() == false) {

                ingang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                uitgang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_ingangActionPerformed

    private void slimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_slimActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            slim.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (dom.isEnabled() == false) {

                slim.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                dom.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_slimActionPerformed

    private void meisjeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_meisjeActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            meisje.setEnabled(false);

        }
        // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
        // CARTA EQUIVALENTE ABAIXO
        if (jongen.isEnabled() == false) {

            meisje.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            jongen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
             
            

        }


    }//GEN-LAST:event_meisjeActionPerformed

    private void vrijActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vrijActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || iemand.isEnabled() == false
                || niemand.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            iemand.setEnabled(true);
            niemand.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            vrij.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (bezet.isEnabled() == false) {

                vrij.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                bezet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_vrijActionPerformed

    private void iemandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iemandActionPerformed

        // Verificação de cartas abertas,  MENOS BOTAO ATUAL E CARTA EQUIVALENTE
        if (slecht.isEnabled() == false
                || goed.isEnabled() == false
                || glanzend.isEnabled() == false
                || dof.isEnabled() == false
                || iets.isEnabled() == false
                || niets.isEnabled() == false
                || vroeg.isEnabled() == false
                || laat.isEnabled() == false
                || ingang.isEnabled() == false
                || uitgang.isEnabled() == false
                || jongen.isEnabled() == false
                || meisje.isEnabled() == false
                || kind.isEnabled() == false
                || volwassene.isEnabled() == false
                || mogelijk.isEnabled() == false
                || onmogelijk.isEnabled() == false
                || kort.isEnabled() == false
                || lang.isEnabled() == false
                || nacht.isEnabled() == false
                || dag.isEnabled() == false
                || licht.isEnabled() == false
                || zwaar.isEnabled() == false
                || bezet.isEnabled() == false
                || vrij.isEnabled() == false
                || gezakt.isEnabled() == false
                || geslaagd.isEnabled() == false
                || vader.isEnabled() == false
                || moeder.isEnabled() == false
                || slim.isEnabled() == false
                || dom.isEnabled() == false) {

            slecht.setEnabled(true);
            goed.setEnabled(true);

            glanzend.setEnabled(true);
            dof.setEnabled(true);

            iets.setEnabled(true);
            niets.setEnabled(true);

            vroeg.setEnabled(true);
            laat.setEnabled(true);

            ingang.setEnabled(true);
            uitgang.setEnabled(true);

            jongen.setEnabled(true);
            meisje.setEnabled(true);

            kind.setEnabled(true);
            volwassene.setEnabled(true);

            mogelijk.setEnabled(true);
            onmogelijk.setEnabled(true);

            kort.setEnabled(true);
            lang.setEnabled(true);

            nacht.setEnabled(true);
            dag.setEnabled(true);

            licht.setEnabled(true);
            zwaar.setEnabled(true);

            bezet.setEnabled(true);
            vrij.setEnabled(true);

            gezakt.setEnabled(true);
            geslaagd.setEnabled(true);

            vader.setEnabled(true);
            moeder.setEnabled(true);

            slim.setEnabled(true);
            dom.setEnabled(true);

        } else {

            // Nome da carta a ser fechada, BOTAO ATUAL
            iemand.setEnabled(false);

            // Desativar cartas iguais; CARTA ATUAL: E CARTA EQUIVALENTE
            // CARTA EQUIVALENTE ABAIXO
            if (niemand.isEnabled() == false) {

                iemand.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
                niemand.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/check.png")));
            }
        }

    }//GEN-LAST:event_iemandActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed

        // Tornar invisível
        setVisible(false);

        //Tempo para reiniciar. 0 = Instantâneo
        try {
            Thread.sleep(0);
        } catch (InterruptedException e1) {
            e1.printStackTrace();
        }

        //Gerar centralizado
        setLocationRelativeTo(null);

        //Tornar Visível
        setVisible(true);

         // Abrir casas fechadas
        slecht.setEnabled(true);
        goed.setEnabled(true);

        iemand.setEnabled(true);
        niemand.setEnabled(true);

        glanzend.setEnabled(true);
        dof.setEnabled(true);

        iets.setEnabled(true);
        niets.setEnabled(true);

        vroeg.setEnabled(true);
        laat.setEnabled(true);

        ingang.setEnabled(true);
        uitgang.setEnabled(true);

        jongen.setEnabled(true);
        meisje.setEnabled(true);

        kind.setEnabled(true);
        volwassene.setEnabled(true);

        mogelijk.setEnabled(true);
        onmogelijk.setEnabled(true);

        kort.setEnabled(true);
        lang.setEnabled(true);

        nacht.setEnabled(true);
        dag.setEnabled(true);

        licht.setEnabled(true);
        zwaar.setEnabled(true);

        bezet.setEnabled(true);
        vrij.setEnabled(true);

        gezakt.setEnabled(true);
        geslaagd.setEnabled(true);

        vader.setEnabled(true);
        moeder.setEnabled(true);

        slim.setEnabled(true);
        dom.setEnabled(true);


    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
        JOptionPane.showMessageDialog(null, "Desenvolvido por:\n"
                + "Chrysthian Chrisley\n"
                + "04/2014\n"
                + "cytchrisley@gmail.com\n"
                + "");

        int answer = JOptionPane.showConfirmDialog(this, "Deixe um comentário \n"
                + "no facebook do desenvolvedor?");
        if (answer == JOptionPane.YES_OPTION) {

            try {
                Desktop.getDesktop().browse(new URL("https://www.facebook.com/ChrysthianChrisley").toURI());
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jongenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jongenMouseClicked
       
    }//GEN-LAST:event_jongenMouseClicked

    private void slechtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_slechtMouseClicked
        

    }//GEN-LAST:event_slechtMouseClicked

    private void niemandMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niemandMouseClicked
        
    }//GEN-LAST:event_niemandMouseClicked

    private void moederMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_moederMouseClicked
       
    }//GEN-LAST:event_moederMouseClicked

    private void onmogelijkMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_onmogelijkMouseClicked
        
    }//GEN-LAST:event_onmogelijkMouseClicked

    private void meisjeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_meisjeMouseClicked
        
    }//GEN-LAST:event_meisjeMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Antoniemen.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Antoniemen.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Antoniemen.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Antoniemen.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Antoniemen().setVisible(true);

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bezet;
    private javax.swing.JButton dag;
    private javax.swing.JButton dof;
    private javax.swing.JButton dom;
    private javax.swing.JButton geslaagd;
    private javax.swing.JButton gezakt;
    private javax.swing.JButton glanzend;
    private javax.swing.JButton goed;
    private javax.swing.JButton iemand;
    private javax.swing.JButton iets;
    private javax.swing.JButton ingang;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton jongen;
    private javax.swing.JButton kind;
    private javax.swing.JButton kort;
    private javax.swing.JButton laat;
    private javax.swing.JButton lang;
    private javax.swing.JButton licht;
    private javax.swing.JButton meisje;
    private javax.swing.JButton moeder;
    private javax.swing.JButton mogelijk;
    private javax.swing.JButton nacht;
    private javax.swing.JButton niemand;
    private javax.swing.JButton niets;
    private javax.swing.JButton onmogelijk;
    private javax.swing.JButton slecht;
    private javax.swing.JButton slim;
    private javax.swing.JButton uitgang;
    private javax.swing.JButton vader;
    private javax.swing.JButton volwassene;
    private javax.swing.JButton vrij;
    private javax.swing.JButton vroeg;
    private javax.swing.JButton zwaar;
    // End of variables declaration//GEN-END:variables
}
