package br.com.chrisley;

/**
 *
 * @author chrysthian.chrisley
 */
public class main {

    public static void main(String[] args) {

        Antoniemen antonimos = new Antoniemen();
        antonimos.setVisible(true);

        {

        }
    }

}
